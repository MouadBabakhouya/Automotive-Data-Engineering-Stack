from datetime import datetime
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.exceptions import AirflowSkipException
import sys
import os
import pendulum
import logging

# Configuration du logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# --- CONFIGURATION DES CHEMINS (ADAPTÉ À VOTRE PC) ---
BASE_PROJECT_PATH = r'C:\Users\mouad.DESKTOP-VVUTG6U\Downloads\project ideas Big data\Real-Time-Car-Price-Recommendation-and-Prediction-System-with-Kafka-and-Spark-main'
SCRAPING_DIR = os.path.join(BASE_PROJECT_PATH, 'scraping')

if SCRAPING_DIR not in sys.path:
    sys.path.append(SCRAPING_DIR)

# Import des fonctions principales des scrapers
try:
    from avito_scraper import main as avito_main
    from moteur_scraper import main as moteur_main
except ImportError as e:
    logger.error(f"Erreur d'importation des scrapers : {e}")
    avito_main = None
    moteur_main = None

# Arguments par défaut
default_args = {
    'owner': 'mouad',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
}

# Fonction pour vérifier si l'heure est entre 8h00 et minuit (Casablanca)
def check_time_window(**kwargs):
    local_tz = pendulum.timezone("Africa/Casablanca")
    now = datetime.now(local_tz)
    hour = now.hour
    
    if not (8 <= hour < 24):
        logger.info(f"Saut de l'exécution : L'heure {now} est en dehors de la fenêtre 8:00-00:00")
        raise AirflowSkipException(f"Fenêtre horaire fermée")

# Wrappers pour l'exécution avec gestion du répertoire de travail
def run_avito_scraper(**kwargs):
    logger.info("🚀 Démarrage de avito_scraper")
    os.chdir(SCRAPING_DIR) # Important pour Selenium et les logs locaux
    try:
        if avito_main:
            avito_main()
            logger.info("✅ avito_scraper terminé avec succès")
        else:
            raise Exception("avito_main n'a pas pu être importé")
    except Exception as e:
        logger.error(f"❌ Échec de avito_scraper : {str(e)}")
        raise

def run_moteur_scraper(**kwargs):
    logger.info("🚀 Démarrage de moteur_scraper")
    os.chdir(SCRAPING_DIR)
    try:
        if moteur_main:
            moteur_main()
            logger.info("✅ moteur_scraper terminé avec succès")
        else:
            raise Exception("moteur_main n'a pas pu être importé")
    except Exception as e:
        logger.error(f"❌ Échec de moteur_scraper : {str(e)}")
        raise

# DAG pour Avito (Toutes les 15 minutes)
with DAG(
    'avito_scraping_pipeline',
    default_args=default_args,
    description='Collecte Avito toutes les 15 min (8h-00h)',
    schedule_interval='*/15 8-23 * * *',
    start_date=datetime(2025, 4, 27, tzinfo=pendulum.timezone("Africa/Casablanca")),
    catchup=False,
    max_active_runs=1,
) as avito_dag:

    check_avito_time = PythonOperator(
        task_id='check_avito_time_window',
        python_callable=check_time_window,
    )

    avito_task = PythonOperator(
        task_id='run_avito_scraper',
        python_callable=run_avito_scraper,
    )

    check_avito_time >> avito_task

# DAG pour Moteur.ma (Toutes les 30 minutes)
with DAG(
    'moteur_scraping_pipeline',
    default_args=default_args,
    description='Collecte Moteur.ma toutes les 30 min (8h-00h)',
    schedule_interval='*/30 8-23 * * *',
    start_date=datetime(2025, 4, 27, tzinfo=pendulum.timezone("Africa/Casablanca")),
    catchup=False,
    max_active_runs=1,
) as moteur_dag:

    check_moteur_time = PythonOperator(
        task_id='check_moteur_time_window',
        python_callable=check_time_window,
    )

    moteur_task = PythonOperator(
        task_id='run_moteur_scraper',
        python_callable=run_moteur_scraper,
    )

    check_moteur_time >> moteur_task