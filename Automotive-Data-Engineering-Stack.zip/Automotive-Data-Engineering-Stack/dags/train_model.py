from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
import os
import sys
import pendulum
import logging

# --- CONFIGURATION DES CHEMINS (ADAPTÉ À VOTRE PC) ---
# Chemin vers le dossier de prédiction pour importer model.py
BASE_PROJECT_PATH = r'C:\Users\mouad.DESKTOP-VVUTG6U\Downloads\project ideas Big data\Real-Time-Car-Price-Recommendation-and-Prediction-System-with-Kafka-and-Spark-main'
MODEL_DIR = os.path.join(BASE_PROJECT_PATH, 'prediction')

if MODEL_DIR not in sys.path:
    sys.path.append(MODEL_DIR)

# Import de la fonction principale de model.py
try:
    from model import main as train_model
except ImportError:
    # Fallback si l'import direct échoue selon la configuration Airflow
    train_model = None

# Logger
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Fuseau horaire (Casablanca)
local_tz = pendulum.timezone("Africa/Casablanca")

default_args = {
    'owner': 'mouad', # Changé de hamzabji à mouad
    'depends_on_past': False,
    'email_on_failure': False, # Mis à False sauf si vous avez configuré un serveur SMTP
    'email_on_retry': False,
    'retries': 1,
}

# Wrapper pour l'entraînement
def run_model_training(**kwargs):
    logger.info("🚀 Démarrage de l'entraînement du modèle de prédiction des prix...")
    if train_model is None:
        raise ImportError(f"Impossible de trouver le script model.py dans {MODEL_DIR}")
    
    try:
        train_model()
        logger.info("✅ Entraînement du modèle terminé avec succès.")
    except Exception as e:
        logger.error(f"❌ Échec de l'entraînement : {str(e)}")
        raise

# Définition du DAG (Uniquement pour le Prix, pas de recommandations)
with DAG(
    dag_id='monthly_price_prediction_training',
    default_args=default_args,
    description='Réentraînement mensuel du modèle Deep Learning de prix (1er du mois à 2h)',
    schedule_interval='0 2 1 * *', 
    start_date=datetime(2025, 6, 1, tzinfo=local_tz),
    catchup=False,
    max_active_runs=1,
    tags=['ml', 'prediction', 'price'],
) as dag:

    training_task = PythonOperator(
        task_id='train_car_price_model',
        python_callable=run_model_training,
        provide_context=True,
    )