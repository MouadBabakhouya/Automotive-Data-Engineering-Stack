import pandas as pd
import warnings
warnings.filterwarnings('ignore')

print("="*60)
print("   TEST DE QUALITÉ DES DONNÉES - PROJET BIG DATA")
print("="*60)

# Charger les données
print("\n📊 Chargement des données...")
try:
    cars = pd.read_csv('cleaned_data.csv', encoding='utf-8')
    print("✅ cleaned_data.csv chargé avec succès")
except:
    try:
        cars = pd.read_csv('cleaned_data.csv', encoding='latin1')
        print("✅ cleaned_data.csv chargé avec succès (latin1)")
    except Exception as e:
        print(f"❌ Erreur : {e}")
        exit()

print("\n" + "="*60)
print("   1. STATISTIQUES GÉNÉRALES")
print("="*60)

print(f"\n📈 Nombre total d'annonces : {len(cars):,}")
print(f"📊 Nombre de colonnes : {len(cars.columns)}")
print(f"💾 Taille mémoire : {cars.memory_usage(deep=True).sum() / 1024**2:.2f} MB")

print("\n📋 Colonnes disponibles :")
for i, col in enumerate(cars.columns, 1):
    print(f"   {i:2d}. {col}")

print("\n" + "="*60)
print("   2. ANALYSE DES SOURCES (Big Data)")
print("="*60)

if 'source' in cars.columns:
    source_counts = cars['source'].value_counts()
    print("\n📡 Répartition par source :")
    for source, count in source_counts.items():
        percentage = (count / len(cars)) * 100
        print(f"   • {source:15s} : {count:5,} annonces ({percentage:5.1f}%)")
else:
    print("⚠️  Colonne 'source' non trouvée")

print("\n" + "="*60)
print("   3. ANALYSE DES PRIX")
print("="*60)

if 'price' in cars.columns:
    print(f"\n💰 Prix minimum    : {cars['price'].min():>12,} MAD")
    print(f"💰 Prix maximum    : {cars['price'].max():>12,} MAD")
    print(f"💰 Prix moyen      : {cars['price'].mean():>12,.0f} MAD")
    print(f"💰 Prix médian     : {cars['price'].median():>12,.0f} MAD")
    
    # Distribution
    print("\n📊 Distribution des prix :")
    ranges = [
        (0, 50000, "< 50K"),
        (50000, 100000, "50K - 100K"),
        (100000, 200000, "100K - 200K"),
        (200000, 300000, "200K - 300K"),
        (300000, 500000, "300K - 500K"),
        (500000, float('inf'), "> 500K")
    ]
    
    for min_p, max_p, label in ranges:
        count = len(cars[(cars['price'] >= min_p) & (cars['price'] < max_p)])
        if count > 0:
            percentage = (count / len(cars)) * 100
            print(f"   • {label:15s} : {count:5,} annonces ({percentage:5.1f}%)")

print("\n" + "="*60)
print("   4. ANALYSE DES MARQUES")
print("="*60)

if 'brand' in cars.columns:
    top_brands = cars['brand'].value_counts().head(10)
    print("\n🚗 Top 10 des marques :")
    for i, (brand, count) in enumerate(top_brands.items(), 1):
        percentage = (count / len(cars)) * 100
        print(f"   {i:2d}. {brand:20s} : {count:5,} annonces ({percentage:5.1f}%)")
    
    print(f"\n📊 Nombre total de marques différentes : {cars['brand'].nunique()}")

print("\n" + "="*60)
print("   5. ANALYSE GÉOGRAPHIQUE")
print("="*60)

if 'seller_city' in cars.columns:
    top_cities = cars['seller_city'].value_counts().head(10)
    print("\n📍 Top 10 des villes :")
    for i, (city, count) in enumerate(top_cities.items(), 1):
        percentage = (count / len(cars)) * 100
        print(f"   {i:2d}. {city:25s} : {count:5,} annonces ({percentage:5.1f}%)")
    
    print(f"\n📊 Nombre total de villes : {cars['seller_city'].nunique()}")

print("\n" + "="*60)
print("   6. CARACTÉRISTIQUES TECHNIQUES")
print("="*60)

if 'fuel_type' in cars.columns:
    print("\n⛽ Types de carburant :")
    for fuel, count in cars['fuel_type'].value_counts().items():
        percentage = (count / len(cars)) * 100
        print(f"   • {fuel:15s} : {count:5,} annonces ({percentage:5.1f}%)")

if 'transmission' in cars.columns:
    print("\n⚙️  Types de transmission :")
    for trans, count in cars['transmission'].value_counts().items():
        percentage = (count / len(cars)) * 100
        print(f"   • {trans:15s} : {count:5,} annonces ({percentage:5.1f}%)")

if 'year' in cars.columns:
    print(f"\n📅 Année minimum : {cars['year'].min()}")
    print(f"📅 Année maximum : {cars['year'].max()}")
    print(f"📅 Année moyenne : {cars['year'].mean():.0f}")

print("\n" + "="*60)
print("   7. QUALITÉ DES DONNÉES")
print("="*60)

print("\n🔍 Valeurs manquantes par colonne :")
missing = cars.isnull().sum()
missing_pct = (missing / len(cars)) * 100
missing_df = pd.DataFrame({
    'Colonne': missing.index,
    'Manquants': missing.values,
    'Pourcentage': missing_pct.values
})
missing_df = missing_df[missing_df['Manquants'] > 0].sort_values('Manquants', ascending=False)

if len(missing_df) > 0:
    for _, row in missing_df.iterrows():
        print(f"   • {row['Colonne']:20s} : {row['Manquants']:6,.0f} ({row['Pourcentage']:5.1f}%)")
else:
    print("   ✅ Aucune valeur manquante détectée !")

print("\n🔍 Doublons :")
duplicates = cars.duplicated().sum()
if duplicates > 0:
    print(f"   ⚠️  {duplicates} lignes dupliquées trouvées ({duplicates/len(cars)*100:.1f}%)")
else:
    print("   ✅ Aucun doublon détecté")

print("\n" + "="*60)
print("   8. DONNÉES TEMPORELLES")
print("="*60)

if 'publication_date' in cars.columns:
    print("\n📅 Dates de publication :")
    try:
        cars['publication_date'] = pd.to_datetime(cars['publication_date'], format='%d/%m/%Y %H:%M', errors='coerce')
        print(f"   • Date la plus ancienne : {cars['publication_date'].min()}")
        print(f"   • Date la plus récente  : {cars['publication_date'].max()}")
        
        # Annonces par jour
        cars['date_only'] = cars['publication_date'].dt.date
        daily_counts = cars['date_only'].value_counts().sort_index()
        print(f"\n📊 Annonces par jour (derniers 5 jours) :")
        for date, count in daily_counts.tail().items():
            print(f"   • {date} : {count:5,} annonces")
    except:
        print("   ⚠️  Format de date non standard")

print("\n" + "="*60)
print("   RÉSUMÉ FINAL")
print("="*60)

print("\n✅ TESTS RÉUSSIS :")
print(f"   • {len(cars):,} annonces chargées")
print(f"   • {len(cars.columns)} colonnes présentes")
print(f"   • {cars['brand'].nunique()} marques différentes")
print(f"   • {cars['seller_city'].nunique()} villes couvertes")

quality_score = 100 - (missing.sum() / (len(cars) * len(cars.columns)) * 100)
print(f"\n📊 Score de qualité des données : {quality_score:.1f}%")

if quality_score > 90:
    print("   🌟 Excellente qualité !")
elif quality_score > 75:
    print("   ✅ Bonne qualité")
elif quality_score > 50:
    print("   ⚠️  Qualité moyenne")
else:
    print("   ❌ Qualité faible")

print("\n" + "="*60)
print("   TEST TERMINÉ")
print("="*60)