# 🚗 Plateforme Big Data : Analyse & Prédiction du Marché Automobile Marocain

![Python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54)
![Apache Spark](https://img.shields.io/badge/Apache%20Spark-E25A1C?style=for-the-badge&logo=apachespark&logoColor=white)
![Apache Kafka](https://img.shields.io/badge/Apache%20Kafka-231F20?style=for-the-badge&logo=apache-kafka&logoColor=white)
![Apache Airflow](https://img.shields.io/badge/Apache%20Airflow-017CEE?style=for-the-badge&logo=Apache%20Airflow&logoColor=white)
![Cassandra](https://img.shields.io/badge/cassandra-%231287B1.svg?style=for-the-badge&logo=apache-cassandra&logoColor=white)

## 📊 Présentation du Projet
Ce projet est une infrastructure **Big Data End-to-End** conçue pour surveiller, nettoyer et analyser les tendances du marché automobile d'occasion au Maroc. Le système extrait des données en temps réel de plateformes leaders (**Avito.ma** et **Moteur.ma**), les traite via un pipeline distribué, et fournit des estimations de prix précises grâce à l'intelligence artificielle.



## 🏗️ Architecture du Pipeline
L'architecture repose sur une stack **SMACK** simplifiée et orchestrée pour la performance :

1.  **Ingestion (Scraping) :** Collecte automatisée via Selenium pilotée par **Apache Airflow**.
2.  **Streaming :** Ingestion massive des données dans **Apache Kafka** pour découpler la collecte du traitement.
3.  **Traitement (ETL) :** Nettoyage, normalisation et déduplication des annonces avec **Apache Spark**.
4.  **Stockage :** Persistance des données structurées dans **Apache Cassandra** (NoSQL).
5.  **Analyse & ML :** * Prédiction de prix via des modèles de **Deep Learning** (TensorFlow).
    * Visualisation décisionnelle via **Tableau Public**.

---

## 🛠️ Stack Technique
| Composant | Technologie | Utilisation |
| :--- | :--- | :--- |
| **Orchestration** | Apache Airflow | Gestion et scheduling des DAGs |
| **Collecte** | Selenium & Python | Extraction web dynamique |
| **Messaging** | Apache Kafka | Flux de données en temps réel |
| **Traitement** | Apache Spark | Transformation de données à grande échelle |
| **Base de données**| Apache Cassandra | Stockage NoSQL scalable |
| **Machine Learning**| TensorFlow / Keras | Modèles de prédiction de prix (`.h5`) |
| **Visualisation** | Tableau | Dashboards BI interactifs |

---

## 📂 Structure du Répertoire
```text
.
├── dags/                # Orchestration Airflow (Scraping & ML Training)
├── scraping/            # Scripts d'extraction (Avito & Moteur)
├── kafka/               # Producers et Consumers Kafka
├── spark/               # Scripts Spark (Cleaning & Transformation)
├── prediction/          # IA : Modèles, Scalers et API Flask de prédiction
├── documentations/      # Guides techniques (Cassandra, Airflow, Setup)
├── data/                # Stockage des fichiers de données brutes
├── cleaned_data.csv     # Dataset final consolidé (700+ annonces)
├── Car price Analysis.twbx # Workbook Tableau pour l'analyse visuelle
└── test_data_quality.py # Script de validation de l'intégrité des données

🚀 Installation & Configuration Rapide
1. Prérequis
    OS : Ubuntu 20.04+ ou Windows avec WSL2.

    Environnements : Python 3.10 (cenv) et Python 3.12 (venv pour Airflow).

    Java : OpenJDK 11 impératif pour Spark et Cassandra.

2. Démarrage des Services
# 1. Cassandra
~/cassandra/bin/cassandra -R

# 2. Kafka & Zookeeper
~/kafka/bin/zookeeper-server-start.sh -daemon ~/kafka/config/zookeeper.properties
~/kafka/bin/kafka-server-start.sh -daemon ~/kafka/config/server.properties

# 3. Airflow
airflow webserver --port 8080 & airflow scheduler

3. Lancement du Pipeline:
# Ingestion manuelle (si non programmée via Airflow)
python scraping/avito_scraper.py

# Traitement Spark
spark-submit --packages org.apache.spark:spark-sql-kafka-0-10_2.12:3.5.0 spark/spark_cleaning.py

# API de Prédiction
cd prediction && python ml_service.py

📈 Résultats & Qualité
Volume : Plus de 700 annonces traitées en temps réel.

Qualité : Taux de complétude des données de 88.8%.

Précision : Modèle ML optimisé pour le marché marocain (45 marques, 112 villes).

Vitesse : Traitement de l'annonce du web à la base de données en moins de 10 secondes.

🔮 Évolutions Futures
[ ] Intégration de nouvelles sources (Sayarti, Autocaz).

[ ] Monitoring en temps réel avec Prometheus/Grafana.

[ ] Conteneurisation complète via Docker Compose.



Projet réalisé dans le cadre du module gestion Framework Hadoop (Big Data) - 2026